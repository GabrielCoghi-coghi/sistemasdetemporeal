#include <Arduino.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

typedef struct {
  float temperatura;
  unsigned long timestamp;
} SensorData;

// Handles para as filas e mutex
QueueHandle_t sensorqueue;
QueueHandle_t logqueue;
SemaphoreHandle_t mutex;

void TaskSensor(void *pv) {
  SensorData data;
  while (1) {
    // Simula leitura (ex: 25.5C vira 255)
    data.temperatura = (float)random(200, 350); 
    data.timestamp = millis();

    // Envia para a fila de processamento
    xQueueSend(sensorqueue, &data, portMAX_DELAY);

    // Correção: pdMS_TO_TICKS
    vTaskDelay(pdMS_TO_TICKS(1000)); 
  }
}

void TaskProcessing(void *pv) {
  SensorData data;
  while (1) {
    // Espera o dado chegar da TaskSensor
    if (xQueueReceive(sensorqueue, &data, portMAX_DELAY) == pdTRUE) {
      data.temperatura = data.temperatura / 10.0; // Converte para decimal
      
      // Envia para a fila de log
      xQueueSend(logqueue, &data, portMAX_DELAY);
    }
  }
}

void TaskLog(void *pv) {
  SensorData data;
  while (1) {
    // O próprio xQueueReceive já bloqueia a task até ter dado, 
    // eliminando a necessidade do semáforo binário extra.
    if (xQueueReceive(logqueue, &data, portMAX_DELAY) == pdTRUE) {
      
      // Protege o acesso ao Serial
      if (xSemaphoreTake(mutex, portMAX_DELAY) == pdTRUE) {
        Serial.print("Temperatura: ");
        Serial.print(data.temperatura);
        Serial.print(" C | Timestamp: ");
        Serial.println(data.timestamp);

        xSemaphoreGive(mutex); // Correção: Adicionado ';'
      }
    }
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("Sistema Iniciado...");

  // Inicialização de filas e mutex
  sensorqueue = xQueueCreate(5, sizeof(SensorData));
  logqueue = xQueueCreate(5, sizeof(SensorData));
  mutex = xSemaphoreCreateMutex();

  if (sensorqueue != NULL && logqueue != NULL && mutex != NULL) {
    xTaskCreate(TaskSensor, "Sensor", 2048, NULL, 2, NULL);
    xTaskCreate(TaskProcessing, "Processing", 2048, NULL, 2, NULL);
    xTaskCreate(TaskLog, "Log", 2048, NULL, 1, NULL);
  } else {
    Serial.println("Erro ao criar recursos!");
  }
}

void loop() {
  // O loop fica vazio no FreeRTOS/Arduino quando usamos tasks
  vTaskDelete(NULL); 
}